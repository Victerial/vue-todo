<script setup>
import axios from 'axios';
import { onMounted , ref } from 'vue';
const todos = ref([])

onMounted(() => {
  axios.get("http://localhost:3000/todos")
    .then(resp => {
      console.table(resp.data);
      todos.value = resp.data;    
    })
  }
)

const deleteTask = (id) =>{
  axios.delete('http://localhost:3000/todos/' + id)
  .then(() => {
    todos.value = todos.value.filter(todo => todo.id != id)
  })
}

const asd = "";

const taskDone = (id) => {
  axios.patch(`http://localhost:3000/todos/` + id)
  .then(() => {
    if(todo.id == id)
      {
       asd =  todo.done == true
      }
  })
};



</script>

<template>
  <div class="container">
    <div class="row">
      <div class="card col-12 col-md-6" v-for="t in todos" :key="t.id">
        <div class="card-body">
          <p v-if="t.done != 'true'" class=" card-text h3 text-center">{{ t.task }}</p>
          <p v-if="t.done != 'false'" class="text-light card-text h3 text-center">{{ t.task }}</p>
          <p class="card-text h5 text-center">{{ t.deadline }}</p>
        </div>
        <div class="card-footer">
          <p @click="deleteTask(t.id)" class="btn btn-danger  w-50 ">Törlés</p>
          <p v-if="asd==true" @click="hidden" class="btn btn-success w-50 ">Kész</p>
        </div>
      </div>
    </div>
  </div>  

</template>
