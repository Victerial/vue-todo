//import './assets/main.css'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import Toast from "vue-toastification";
import "vue-toastification/dist/index.css";

import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

const app = createApp(App)

const options = {
    draggable: false,
    //position: POSITION.BOTTOM
};

app.use(Toast, options)
app.use(router)

app.mount('#app')
